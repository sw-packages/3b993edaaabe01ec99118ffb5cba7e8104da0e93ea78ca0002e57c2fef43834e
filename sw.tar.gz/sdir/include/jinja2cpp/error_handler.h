#ifndef JINJA2CPP_ERROR_HANDLER_H
#define JINJA2CPP_ERROR_HANDLER_H

#include "template.h"

namespace jinja2
{

class IErrorHandler
{
public:
};

} // jinja2

#endif // JINJA2CPP_DIAGNOSTIC_CONSUMER_H
